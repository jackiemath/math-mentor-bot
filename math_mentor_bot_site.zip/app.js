
let currentMode = 'homework';

function selectMode(mode) {
  currentMode = mode;
  addMessage("Bot", `You selected: ${mode.replace('_', ' ')}. Enter your problem below.`);
}

function handleKeyPress(e) {
  if (e.key === 'Enter') sendMessage();
}

function sendMessage() {
  let input = document.getElementById('userInput').value;
  if (input.trim() === '') return;
  addMessage("You", input);
  processInput(input);
  document.getElementById('userInput').value = '';
}

function addMessage(sender, text) {
  let messages = document.getElementById('messages');
  messages.innerHTML += `<p><strong>${sender}:</strong> ${text}</p>`;
  messages.scrollTop = messages.scrollHeight;
}

function processInput(input) {
  if (currentMode === 'homework') {
    addMessage("Bot", `Let's solve: \(${input}\)`);
    MathJax.typeset();
  } else if (currentMode === 'generate') {
    addMessage("Bot", "Generating a random problem...");
  } else {
    addMessage("Bot", "Feature coming soon!");
  }
}
